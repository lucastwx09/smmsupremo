<?php
//Config Database
define('DB_HOST', 'localhost');
define('DB_USER', 'mirandar_vox');
define('DB_PASS', 'torelly1616');
define('DB_NAME', 'mirandar_vox');
define('TIMEZONE', 'Asia/Kolkata');
define('ENCRYPTION_KEY', 'c5fbb0694cb9c7e6dda5926478149672');
